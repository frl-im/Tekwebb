

<?php $__env->startSection('content'); ?>
  <article>
    <h1><?php echo e($new_berita["judul"]); ?></h1>
    <h3><?php echo e($new_berita["penulis"]); ?></h3>
    <p><?php echo e($new_berita["konten"]); ?></p>
 </article>
    
    <a href="/berita">Kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel11\resources\views\halamanberita.blade.php ENDPATH**/ ?>